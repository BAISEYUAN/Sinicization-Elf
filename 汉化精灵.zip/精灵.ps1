﻿Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$f=New-Object Windows.Forms.Form
$f.Text='汉化精灵 v1.4'
$f.Size=New-Object Drawing.Size(480,380)
$f.StartPosition='CenterScreen'
$f.FormBorderStyle='FixedDialog'
$f.MaximizeBox=$false
$f.BackColor='#0f172a'
$l=New-Object Windows.Forms.Label
$l.Text='汉化精灵'
$l.Font=New-Object Drawing.Font('Microsoft YaHei',22,[System.Drawing.FontStyle]::Bold)
$l.ForeColor='#a5b4fc'
$l.Size=New-Object Drawing.Size(440,50)
$l.Location=New-Object Drawing.Point(20,20)
$l.TextAlign=32
$f.Controls.Add($l)
$b=New-Object Windows.Forms.Button
$b.Text='开始汉化'
$b.Size=New-Object Drawing.Size(440,48)
$b.Location=New-Object Drawing.Point(20,110)
$b.BackColor='#6366f1'
$b.ForeColor='White'
$b.FlatStyle=0
$f.Controls.Add($b)
$t=New-Object Windows.Forms.Label
$t.Text='请关闭ChatGPT后点击开始'
$t.ForeColor='#64748b'
$t.Size=New-Object Drawing.Size(440,36)
$t.Location=New-Object Drawing.Point(20,170)
$t.TextAlign=32
$f.Controls.Add($t)
$p=New-Object Windows.Forms.ProgressBar
$p.Size=New-Object Drawing.Size(440,6)
$p.Location=New-Object Drawing.Point(20,215)
$f.Controls.Add($p)
$v=New-Object Windows.Forms.Label
$v.Text='v1.4.0 | 仅支持微软商店版ChatGPT'
$v.ForeColor='#475569'
$v.Size=New-Object Drawing.Size(440,36)
$v.Location=New-Object Drawing.Point(20,260)
$v.TextAlign=32
$f.Controls.Add($v)
$sd=$env:USERPROFILE+'\.codex\skills\codex-windows-fast-patch-skill'
$sp="$sd\scripts\patch_codex_fast_mode_windows_msix.ps1"
$su="$sd\scripts\update-skill-from-github.ps1"
$b.Add_Click({
$b.Enabled=0;$b.Text='检测中...'
$t.Text='检测ChatGPT...';$p.Value=3
$pkg=Get-AppxPackage -Name OpenAI.Codex -ErrorAction SilentlyContinue
if(-not $pkg){$t.Text='请先安装微软商店版ChatGPT!';$b.Enabled=1;$b.Text='未检测到';return}
if($pkg.SignatureKind -eq 'Developer'){$t.Text='已汉化,无需重复';$b.Enabled=1;$b.Text='已汉化';$p.Value=100;return}
$t.Text='检查Node.js...';$p.Value=5
if(-not(Get-Command node -ErrorAction SilentlyContinue)){$t.Text='安装Node.js...';$p.Value=10
try{winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements}catch{$t.Text='下载Node.js...';$z=$env:TEMP+'\node.msi';iwr 'https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi' -OutFile $z;Start-Process msiexec -Args "/i `"$z`" /quiet /norestart" -Wait;ri $z -Force}
$env:Path=[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')}
$t.Text='更新补丁脚本...';$p.Value=15
try{Start-Process powershell("-NoProfile -Ep Bypass -File `"$su`"") -Wait -NoNewWindow}catch{}
$psc=Get-Content "$sp" -Raw
$psc=$psc.Replace("Fail 'could not find custom model visibility filter in extracted assets'","Write-Warning 'custom model visibility filter not found; continuing without custom models patch'")
Set-Content "$sp" -Value $psc -Encoding UTF8
if(-not(Test-Path $sp)){$t.Text='更新失败,重新下载...';$p.Value=18
try{$u='https://api.github.com/repos/chen0416ccc-cpu/codex-windows-fast-patch-skill/zipball/main';$z=$env:TEMP+'\fp.zip';iwr -Uri $u -OutFile $z;Expand-Archive $z ($env:TEMP+'\fp') -Force;$i=dir($env:TEMP+'\fp') -Dir|select -First 1;if(Test-Path $sd){ri $sd -Recurse -Force};mv $i.FullName $sd;ri $z,($env:TEMP+'\fp') -Recurse -Force;Set-Content "$sp" -Value $psc -Encoding UTF8}catch{$t.Text='网络错误';$b.Enabled=1;$b.Text='重试';return}}
$t.Text='汉化中(10-20min)...';$p.Value=50
try{Start-Process powershell("-NoProfile -Ep Bypass -File `"$sp`" -InstallPrerequisites -Install -Launch -CleanupAfter -CleanupWindowsSdkAfterInstall") -Wait -NoNewWindow
$c=Get-AppxPackage -Name OpenAI.Codex -ErrorAction SilentlyContinue
if(-not $c){$t.Text='失败!从商店重装ChatGPT后重试';$b.Text='失败';$b.Enabled=1;$b.BackColor='#ef4444';return}
$p.Value=100;$t.Text='完成!';$b.Text='关闭';$b.Enabled=1}catch{$t.Text='ChatGPT版本太新暂不支持,请等1-2天后重试';$b.Enabled=1;$b.Text='重试'}
})
$f.ShowDialog()