﻿Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$f=New-Object Windows.Forms.Form
$f.Text='汉化精灵 v1.0'
$f.Size=New-Object Drawing.Size(480,320)
$f.StartPosition='CenterScreen'
$f.FormBorderStyle='FixedDialog'
$f.MaximizeBox=$false
$f.BackColor='#0f172a'
$l=New-Object Windows.Forms.Label
$l.Text='汉化精灵'
$l.Font=New-Object Drawing.Font('Microsoft YaHei',22,1)
$l.ForeColor='#a5b4fc'
$l.Size=New-Object Drawing.Size(440,50)
$l.Location=New-Object Drawing.Point(20,20)
$l.TextAlign=32
$f.Controls.Add($l)
$b=New-Object Windows.Forms.Button
$b.Text='开始汉化'
$b.Size=New-Object Drawing.Size(440,48)
$b.Location=New-Object Drawing.Point(20,110)
$b.BackColor='#6366f1'
$b.ForeColor='White'
$b.FlatStyle=0
$f.Controls.Add($b)
$t=New-Object Windows.Forms.Label
$t.Text='请关闭ChatGPT后点击开始'
$t.ForeColor='#64748b'
$t.Size=New-Object Drawing.Size(440,20)
$t.Location=New-Object Drawing.Point(20,170)
$t.TextAlign=32
$f.Controls.Add($t)
$p=New-Object Windows.Forms.ProgressBar
$p.Size=New-Object Drawing.Size(440,6)
$p.Location=New-Object Drawing.Point(20,200)
$f.Controls.Add($p)
$v=New-Object Windows.Forms.Label
$v.Text='v1.0.0 | 管理员权限'
$v.ForeColor='#475569'
$v.Size=New-Object Drawing.Size(440,18)
$v.Location=New-Object Drawing.Point(20,250)
$v.TextAlign=32
$f.Controls.Add($v)
$sp=$env:USERPROFILE+'\.codex\skills\codex-windows-fast-patch-skill\scripts\patch_codex_fast_mode_windows_msix.ps1'
$b.Add_Click({
$b.Enabled=0;$b.Text='运行中...'
$t.Text='正在检查...';$p.Value=10
if(Test-Path $sp){
$t.Text='正在汉化(约10-20分钟)...';$p.Value=50
try{Start-Process powershell("-NoProfile -Ep Bypass -File `"$sp`" -InstallPrerequisites -Install -Launch -CleanupAfter -CleanupWindowsSdkAfterInstall") -Wait -NoNewWindow;$p.Value=100;$t.Text='完成! ChatGPT已变为中文';$b.Text='关闭';$b.Enabled=1}catch{$t.Text='出错,请重试';$b.Enabled=1;$b.Text='重试'}
}else{
$t.Text='正在下载组件...';$p.Value=20
try{$u='https://api.github.com/repos/chen0416ccc-cpu/codex-windows-fast-patch-skill/zipball/main';$z=$env:TEMP+'\fp.zip';iwr -Uri $u -OutFile $z;Expand-Archive $z ($env:TEMP+'\fp') -Force;$i=dir($env:TEMP+'\fp') -Dir|select -First 1;$d=$env:USERPROFILE+'\.codex\skills\codex-windows-fast-patch-skill';if(Test-Path $d){ri $d -Recurse -Force};mv $i.FullName $d;ri $z,($env:TEMP+'\fp') -Recurse -Force}catch{$t.Text='下载失败,检查网络';$b.Enabled=1;$b.Text='重试';return}
$t.Text='正在汉化(约10-20分钟)...';$p.Value=50
try{Start-Process powershell("-NoProfile -Ep Bypass -File `"$sp`" -InstallPrerequisites -Install -Launch -CleanupAfter -CleanupWindowsSdkAfterInstall") -Wait -NoNewWindow;$p.Value=100;$t.Text='完成! ChatGPT已变为中文';$b.Text='关闭';$b.Enabled=1}catch{$t.Text='出错,请重试';$b.Enabled=1;$b.Text='重试'}
}
})
$f.ShowDialog()