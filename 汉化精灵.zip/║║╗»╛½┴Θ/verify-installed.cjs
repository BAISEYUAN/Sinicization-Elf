// 汉化结果自检 - 零外部依赖版
// 直接在 app.asar 内做特征串二进制检索(asar 内的 JS 为明文存储),
// 无需 asar 模块、无需解包到磁盘,因此可在任意电脑上运行。
const fs = require('fs');
const path = require('path');

// 动态定位已安装的 Codex 包(app.asar), 不依赖硬编码版本号/用户名
function findAsar() {
  const roots = [
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'WindowsApps'),
    'C:\\Program Files\\WindowsApps'
  ];
  let best = null, bestTime = -1;
  const seen = new Set();
  for (const wa of roots) {
    if (seen.has(wa.toLowerCase())) continue;
    seen.add(wa.toLowerCase());
    if (!fs.existsSync(wa)) continue;
    let dirs = [];
    try { dirs = fs.readdirSync(wa).filter(d => /^OpenAI\.Codex_/i.test(d)); } catch (e) { continue; }
    for (const d of dirs) {
      const p = path.join(wa, d, 'app', 'resources', 'app.asar');
      try {
        if (fs.existsSync(p)) {
          const t = fs.statSync(p).mtimeMs;
          if (t > bestTime) { bestTime = t; best = p; }
        }
      } catch (e) {}
    }
  }
  return best;
}

// 分块检索大文件中的特征串(带重叠窗口,避免跨块漏匹配),内存占用恒定
function fileIncludes(filePath, needleStr) {
  const needle = Buffer.from(needleStr, 'utf8');
  const CHUNK = 8 * 1024 * 1024;
  const overlap = needle.length - 1;
  const fd = fs.openSync(filePath, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    let pos = 0;
    let tail = Buffer.alloc(0);
    while (pos < size) {
      const len = Math.min(CHUNK, size - pos);
      const buf = Buffer.alloc(len);
      fs.readSync(fd, buf, 0, len, pos);
      const hay = tail.length ? Buffer.concat([tail, buf]) : buf;
      if (hay.includes(needle)) return true;
      tail = overlap > 0 && hay.length > overlap
        ? Buffer.from(hay.subarray(hay.length - overlap))
        : Buffer.alloc(0);
      pos += len;
    }
    return false;
  } finally {
    fs.closeSync(fd);
  }
}

const src = process.argv[2] || findAsar();
if (!src) { console.log('RESULT=NO_PACKAGE'); process.exit(0); }

try {
  // 已注入中文默认语言的标志
  const hasZh = fileIncludes(src, "default:'zh-CN',description:`Explicit locale override`");
  // 未打补丁时存在的原始开关形态; 打过补丁后该形态被替换为 =!0 而消失
  const rawSwitch = fileIncludes(src, '?.get(`enable_i18n`,!1)');
  const forcedOn = !rawSwitch;
  console.log('TARGET=' + src);
  console.log('HAS_ZHCN=' + hasZh);
  console.log('FORCED_ON=' + forcedOn);
  console.log('RESULT=' + ((hasZh && forcedOn) ? 'PATCHED' : 'NOT_PATCHED'));
} catch (e) {
  console.log('RESULT=ERROR ' + e.message);
}
